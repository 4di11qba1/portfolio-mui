import { useState } from "react";
import { Typography } from "@mui/material";
import { useTheme } from "../constants/Theme.jsx";
import Carousel from '../components/Carousel.jsx';
import Stepper from "../components/Stepper.jsx";
import { Temp } from "../assets/Index.jsx";

const services = [
  {
    heading: "UI/UX Design",
    img: Temp,
  },
  {
    heading: "Web Development",
    img: Temp,
  },
  {
    heading: "App Development",
    img: Temp,
  },
  {
    heading: "SEO Services",
    img: Temp,
  },
  {
    heading: "Digital Marketing",
    img: Temp,
  },
];

function Services() {
  const { colors } = useTheme();
  const [start, setStart] = useState(0);
  const [end, setEnd] = useState(3);
  const [position, setPosition] = useState(1);

  const handleNext = () => {
    if (end < services.length) {
      setStart(start + 1);
      setEnd(end + 1);
      setPosition(position + 1);
    }
  };

  const handlePrev = () => {
    if (start > 0) {
      setStart(start - 1);
      setEnd(end - 1);
      setPosition(position - 1);
    }
  };

  return (
      <div className="wrapper">
        <div className="wrapper-content">
          <div className="services">
            <div className="services-content">
              <div className="services-header">
                <Typography component={"div"} variant="h3">
                  My{" "}
                  <span style={{ color: colors?.primary, fontWeight: "bold" }}>
                  Services
                </span>
                </Typography>
                <Typography component="div" variant="body1" className="services-text">
                  From creating unique UI/UX designs that enhance user experiences
                  to developing custom solutions, I ensure seamless integration
                  across platforms.
                </Typography>
              </div>
              <Carousel
                  position={position}
                  services={services}
                  start={start}
                  end={end}
                  handleNext={handleNext}
                  handlePrev={handlePrev}
              />
              <div className="stepper-wrapper">
                <Stepper
                    position={position - 1}
                    handleNext={handleNext}
                    handlePrev={handlePrev}
                    steps={services.length - 2} 
                />
              </div>
            </div>
          </div>
        </div>
      </div>
  );
}

export default Services;
