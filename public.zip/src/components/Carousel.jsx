import { AnimatePresence, motion } from "framer-motion";
import ServiceCard from "./ServiceCard.jsx";

// eslint-disable-next-line react/prop-types
function Carousel({ start, end, services }) {
    return (
        <div className="carousel-container">
            <AnimatePresence>
                {/* eslint-disable-next-line react/prop-types */}
                {services.slice(start, end).map((service, index) => (
                    <motion.div
                        key={service.heading}
                        initial={{ opacity: 0, x: 100 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -100 }}
                        transition={{
                            duration: 0.85,
                            delay: index * 0.2, // Delay for entering animation
                            delayChildren: index * 0.2 // Delay for leaving animation
                        }}
                    >
                        <ServiceCard heading={service.heading} img={service.img} />
                    </motion.div>
                ))}
            </AnimatePresence>
        </div>
    );
}

export default Carousel;
