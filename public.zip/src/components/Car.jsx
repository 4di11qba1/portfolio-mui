const MyComponent = () => {
    return (
        <>
            <input id="rad1" name="rad" type="radio" defaultChecked />
            <input id="rad2" name="rad" type="radio" />
            <input id="rad3" name="rad" type="radio" />
            <button className="btn"></button>
            <div id="wrap">
                {/*<input type="checkbox" />*/}
                {[...Array(3)].map((_, i) => (
                    <div className="slide" key={i}>
                        <div className="label"></div>
                        <div className="content">
                            <h1></h1>
                            <p>
                                <span>Locality:</span>
                                <span>Sex:</span>
                            </p>
                        </div>
                        <label>classification</label>
                        <p className="classifications">
                            <span>Class</span>
                            <span>Order</span>
                            <span>Family</span>
                            <span>Subfamily</span>
                            <span>Genus</span>
                            <span>Species</span>
                        </p>
                    </div>
                ))}
            </div>
        </>
    );
};

export default MyComponent;
