export { default as Avatar } from "./Avatar.png";
export { default as Temp } from "./temp.png";
