import Car from "../components/Car";
function Test() {
  return (
    <div className="wrapper" style={{ height: "600px", marginBottom: "30px" }}>
      <div className="wrapper-content">
          <div className={"carousel-test"}>
              <Car />
          </div>
      </div>
    </div>
  );
}

export default Test;
