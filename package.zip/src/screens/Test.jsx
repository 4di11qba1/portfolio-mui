import Carousel from "../components/Carousel";
function Test() {
  return (
    <div className="wrapper" style={{ height: "600px", marginBottom: "30px" }}>
      <div className="wrapper-content">
          <div className={"carousel-test"}>
              <Carousel />
          </div>
      </div>
    </div>
  );
}

export default Test;
