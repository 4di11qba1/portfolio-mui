import React from "react";

function About() {
  return (
    <div className="wrapper">
      <div className="wrapper-content"></div>
    </div>
  );
}

export default About;
